 Towards NALT shapes`
======


This [JupyterBook](https://jupyterbook.org/) provides instructions for building NALT Shapes.


![logo](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Feld_mit_reifer_Baumwolle.jpeg/640px-Feld_mit_reifer_Baumwolle.jpeg "Cotton")

Release v1.0.0 (2021-09-01)